% function params = m2p(HTM)
%    HTM - homogeneous transformation matrix (4x4)
%    params - return value is a row vector of the form
%             [Rx Ry Rz Tx Ty Tz]
%%%% [4] marks total %%%%
function params = m2p(HTM)

    % Placeholder code (change it).
    params = zeros(1,6);


