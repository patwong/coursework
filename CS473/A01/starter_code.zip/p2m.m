% function M = p2m([R1 R2 R3 T1 T2 T3])
%
%   Converts motion parameters to a 4x4 homogeneous transformation matrix.
%   The order of operations is:
%     (1) rotate about axis 1, then axis 2, then axis 3
%     (2) translate by [T1 T2 T3]
%
%   Rotation angles are in degrees
%
%%% [4] marks total %%%
function M = p2m(p)

    % The following code is simply place-holder code.
    % It hard-codes the identity transformation.
    % You need to edit it.
    M = [1 0 0 0;
         0 1 0 0;
         0 0 1 0;
         0 0 0 1];
